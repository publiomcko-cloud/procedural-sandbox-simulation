import json,pathlib,hashlib
root=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R97_D3_20261029_5eab760d7ce6486eaef7fb210741416e\D3.5-artifacts-run1')
for p in sorted(root.glob('*RAY.CANONICAL_PICKER.v1*.json')):
 b=p.read_bytes();o=json.loads(b.replace(b'\x1f',b'\\u001f'));print(p.name,hashlib.sha256(b).hexdigest(),o.keys());print('id',o.get('scenario_id'),o.get('variant_id'),o.get('role'));print('ray keys',o.get('ray_comparison',{}).keys(),o.get('ray_comparison',{}).get('hit_miss_disagreements'),o.get('ray_comparison',{}).get('ray_count'));print('mesh hash',o.get('geometry',{}).get('mesh_sha256'),o.get('mesh_sha256'))
