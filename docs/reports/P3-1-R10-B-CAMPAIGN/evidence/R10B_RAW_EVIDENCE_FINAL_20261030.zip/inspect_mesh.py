import json,pathlib
p=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R10A_20261029_ebc6f0b3b2d44761b988561524bdd50b\R10-A6_geometry\required_equal_lod_gate_full_roi_R9.2.SEAM.XPLUS_EQUAL.v1.json');o=json.loads(p.read_bytes().replace(b'\x1f',b'\\u001f'));m=o['geometry']['mesh'];print('mesh keys',list(m));
for k,v in m.items():
 if isinstance(v,list):print(k,'list',len(v),'sample',v[:3])
 elif isinstance(v,dict):print(k,'dict',len(v),'keys',list(v)[:5])
 else:print(k,type(v).__name__,repr(v)[:200])
