import json,pathlib
p=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R10A_20261029_ebc6f0b3b2d44761b988561524bdd50b\R10-A6_geometry\required_equal_lod_gate_full_roi_R9.2.SEAM.XPLUS_EQUAL.v1.json')
o=json.loads(p.read_bytes().replace(b'\x1f',b'\\u001f')); g=o['geometry']; patch=next(x for x in g['component_reconstruction']['patches'] if x['status']=='UNRESOLVED'); path=patch['boundary']['paths'][0]; arcs=g['topology_graph']['canonical']['arcs']; print('path0 roots',path['root_ids'][:3]);print('path0 edges',path['edge_keys'][:3]);print('arcs sample',arcs[0]);
for ek in path['edge_keys'][:3]:
 matches=[a for a in arcs if ek in a[1]];print('ek',ek,'matchcount',len(matches),'match',matches[:2])
# component root ids and source polygon ids, source polygon orientations
ids=set(patch['source_polygon_ids']); polys=[p for p in g['component_reconstruction']['polygons'] if p.get('id') in ids]
rids=sorted({r for p in polys for r in p['root_ids']});print('component root count',len(rids),'polys',len(polys),'orientation vectors',len({p['toward_empty'] for p in polys}),'orientation sample',list({p['toward_empty'] for p in polys})[:5])
# cr arc shape and sample
cr_arcs=g['component_reconstruction']['arcs'];print('cr arcs',len(cr_arcs),type(cr_arcs[0]).__name__,cr_arcs[0])
# neighbor source polygons sharing one of component root-pair edges
edge_owner={}
for p in g['topology_graph']['canonical']['polygons']:
 pid=p[0]; roots=p[3]
 for i,a in enumerate(roots):
  b=roots[(i+1)%len(roots)]; k='|'.join(sorted([a,b]));edge_owner.setdefault(k,[]).append(pid)
selected=set()
for p in polys:
 roots=p['root_ids']
 for i,a in enumerate(roots):
  b=roots[(i+1)%len(roots)]
  selected.update(x for x in edge_owner.get('|'.join(sorted([a,b])),[]) if x not in ids)
print('external neighbors sharing root edge',len(selected),sorted(selected)[:20])
