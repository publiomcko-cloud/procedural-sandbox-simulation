import json,pathlib
p=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R10A_20261029_ebc6f0b3b2d44761b988561524bdd50b\R10-A6_geometry\required_equal_lod_gate_full_roi_R9.2.SEAM.XPLUS_EQUAL.v1.json')
o=json.loads(p.read_bytes().replace(b'\x1f',b'\\u001f')); g=o['geometry']; patch=next(x for x in g['component_reconstruction']['patches'] if x['status']=='UNRESOLVED'); t=patch['triangulation']; cg=g['topology_graph']['canonical']; cr=g['component_reconstruction']
print('volume',o['volume_sha256'],o['volume_revision'],o['payload_sha256'],'topology',g['topology_sha256'],g['source_topology_graph_proof'])
print('patch',patch['component_id'],patch['source_root_count'],patch['boundary_root_count'],patch['interior_root_count'],len(patch['source_polygon_ids']),patch['source_cell_count'],patch['source_euler_characteristic'])
print('boundary', patch['boundary']['path_count'],patch['boundary']['closed_loop_count'],patch['boundary']['open_path_count'])
path=patch['boundary']['paths'][0]; print('path keys',list(path),'boundary counts',{k:len(v) if isinstance(v,list) else v for k,v in path.items()})
print('triangulation keys',list(t));print('tri summary', {k:(len(v) if isinstance(v,(list,dict)) else v) for k,v in t.items() if k not in ('triangles','flips','interior_root_insertions','remaining_subcutoff_triangles')})
for k in ('remaining_subcutoff_triangles','interior_root_insertions','flips','triangles'):
 v=t.get(k,[]); print(k,'count',len(v),'sample',v[0] if v else None)
roots=cg.get('roots');polys=cg.get('polygons');arcs=cg.get('arcs'); print('canonical types',type(roots).__name__,len(roots),type(polys).__name__,len(polys),type(arcs).__name__,len(arcs))
print('root sample', next(iter(roots.items())) if isinstance(roots,dict) else roots[0]); print('poly sample',next(iter(polys.items())) if isinstance(polys,dict) else polys[0]); print('arc sample',next(iter(arcs.items())) if isinstance(arcs,dict) else arcs[0]);
polys2=cr['polygons']; print('cr poly sample',polys2[0]); selected=[x for x in polys2 if x.get('id') in set(patch['source_polygon_ids'])]; print('selected found',len(selected),'sample',selected[0] if selected else None)
