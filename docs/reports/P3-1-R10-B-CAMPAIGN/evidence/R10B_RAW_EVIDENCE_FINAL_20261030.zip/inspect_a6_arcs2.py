import json,pathlib
p=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R10A_20261029_ebc6f0b3b2d44761b988561524bdd50b\R10-A6_geometry\required_equal_lod_gate_full_roi_R9.2.SEAM.XPLUS_EQUAL.v1.json')
o=json.loads(p.read_bytes().replace(b'\x1f',b'\\u001f'));g=o['geometry'];patch=next(x for x in g['component_reconstruction']['patches'] if x['status']=='UNRESOLVED');arcs=g['component_reconstruction']['arcs'];print('cr arcs',type(arcs).__name__,len(arcs));print('keys',list(arcs)[:5]);k=patch['boundary']['paths'][0]['edge_keys'][0];print('target',repr(k));print('present',k in arcs);print('record',arcs.get(k));
# find matching component arc by any polygon incidence
ids=set(patch['source_polygon_ids']); selected=[]
for k,v in arcs.items():
 if any(pid in ids for pid in v.get('source_polygons',v.get('polygon_ids',[]))): selected.append((k,v))
print('selected arcs',len(selected));print('sample',selected[0] if selected else None)
# source polygon row to keys
