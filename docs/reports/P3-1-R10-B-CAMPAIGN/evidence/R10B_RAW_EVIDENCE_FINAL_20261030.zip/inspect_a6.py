import json, pathlib, sys
root=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R10A_20261029_ebc6f0b3b2d44761b988561524bdd50b')
p=root/'R10-A6_geometry'/'required_equal_lod_gate_full_roi_R9.2.SEAM.XPLUS_EQUAL.v1.json'
b=p.read_bytes(); obj=json.loads(b.replace(b'\x1f',b'\\u001f'))
print('top',list(obj))
g=obj.get('geometry',{})
print('geometry',list(g))
for k in ('topology_graph','source_topology_graph_proof','component_reconstruction','mesh_topology','local_refinement','metrics','cutoff_rejections','required_adjacency_obligations','emitted_triangles'):
 v=g.get(k)
 if isinstance(v,dict): print(k,'keys',list(v),'counts',{x:(len(v[x]) if isinstance(v[x],(list,dict)) else v[x]) for x in v if x in ('roots','polygons','arcs','components','triangles','rejected','patches','source_root_count','interior_root_count','attempted_flips')})
 elif isinstance(v,list): print(k,'len',len(v),'sample',v[0] if v else None)
 else: print(k,type(v).__name__,v)
cr=g.get('component_reconstruction',{})
print('polygons',len(cr.get('polygons',[])), 'arcs',len(cr.get('arcs',[])), 'patches',len(cr.get('patches',[])))
for i,patch in enumerate(cr.get('patches',[])):
 print('PATCH',i,'keys',list(patch))
 for k,v in patch.items():
  if isinstance(v,(dict,list)):
   print(' ',k,'type',type(v).__name__,'len',len(v),'keys' if isinstance(v,dict) else 'sample',list(v)[:12] if isinstance(v,dict) else (v[0] if v else None))
  else: print(' ',k,repr(v)[:200])
print('topology graph sample keys',list(g.get('topology_graph',{})))
for k,v in g.get('topology_graph',{}).items():
 if isinstance(v,(dict,list)): print(' TG',k,type(v).__name__,len(v), (list(v)[:5] if isinstance(v,dict) else (v[0] if v else None)))
