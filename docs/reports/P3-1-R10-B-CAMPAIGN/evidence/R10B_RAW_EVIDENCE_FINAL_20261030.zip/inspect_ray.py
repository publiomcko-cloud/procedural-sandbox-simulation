import json,pathlib
root=pathlib.Path(r'C:\Users\PUBLI\AppData\Local\Temp\P3_1_R10A_20261029_ebc6f0b3b2d44761b988561524bdd50b')
for name in ['R10-A6_geometry/frozen_roi_ray_oracle_R9.2.RAY.CANONICAL_PICKER.v1.json','R10-A6_geometry/required_equal_lod_gate_full_roi_R9.2.SEAM.XPLUS_EQUAL.v1.json']:
 p=root/name; o=json.loads(p.read_bytes().replace(b'\x1f',b'\\u001f'));print(name,list(o));print('summary', {k:v for k,v in o.items() if not isinstance(v,(list,dict))});
 for k,v in o.items():
  if isinstance(v,list):print('array',k,len(v),v[0] if v else None)
  elif isinstance(v,dict):
   print('dict',k,'keys',list(v)[:10]);
   for q,w in v.items():
    if isinstance(w,list):print(' ',q,len(w),w[0] if w else None)
