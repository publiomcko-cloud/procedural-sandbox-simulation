$ErrorActionPreference='Stop'
$run='C:\Users\PUBLI\AppData\Local\Temp\p3_1_r12cx_07c9379_validation_20261031\CX_GEOMETRY_FINAL03'
$checkout='C:\Users\PUBLI\AppData\Local\Temp\p3_1_r12cx_07c9379_validation_20261031\checkout'
$profile='C:\Users\PUBLI\AppData\Local\Temp\p3_1_r12cx_07c9379_validation_20261031\profile'
$godot='C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
$env:APPDATA=Join-Path $profile 'Roaming'
$env:LOCALAPPDATA=Join-Path $profile 'Local'
$env:R12CX_MODE='campaign'
$env:R12C_ATTEMPT_ID='CX_GEOMETRY_FINAL03'
$env:R12C_SOURCE_SHA='07c93797fa3f26d3c9143433638f193e7c5cef00'
$env:R12C_PARENT_SHA='949ceedf70b16dc4043fe1af702c930ff3055b68'
$env:R12C_TREE_SHA='0bda08b44c982a1ec803aa6f6d3f9f1a64dfcf4c'
$env:R12C_C6_SOURCE_SHA='4535f4c965db67adab7c93e448492c54be916c92'
$env:R12C_ARTIFACT_DIR=$run
$env:R12C_FIXTURE_PATH='C:\Users\PUBLI\AppData\Local\Temp\p3_1_r12cx_20261031_39b1deec92464655b0d8cbc11838a5fb\r12c_stage0_topology_fixture.json'
$env:R12CX_RESIDUAL_FIXTURE_PATH=Join-Path $checkout 'game\tests\prototypes\p3_1_r12_cx_residual_fixture.json'
$env:R12C_EXPECTED_CAMPAIGN_SHA256='853858f68fb2b07937eb16bb014e58f33aaf165e7fa47dd7ba9eafda5732d606'
$env:R12C_EXPECTED_REALIZER_SHA256='6c9609fa98573481be63f0d83188e02f9f37cc8c5037c3994185762b8a6ac895'
$env:R12C_EXPECTED_C6_CAMPAIGN_SHA256='9a695705c47ad6473b773bbfaeaf35d88306cee6804113a0b1a71c6faca2f348'
$env:R12C_EXPECTED_C6_REALIZER_SHA256='31947e1944a017442ad14cc4f098e67db800d4f5e196d07e047b93dc0fe9d2ac'
$env:R12CX_EXPECTED_RESIDUAL_FIXTURE_SHA256='ad000594b25a82459da824b7488b2a553392a86e117eb64535b182463847ff23'
$launcherPid=[Diagnostics.Process]::GetCurrentProcess().Id
$sw=[Diagnostics.Stopwatch]::StartNew()
$stdout=Join-Path $run 'stdout.txt'
$stderr=Join-Path $run 'stderr.txt'
$proc=Start-Process -FilePath $godot -ArgumentList @('--headless','--path','./game','--script','res://tests/prototypes/p3_1_r12_cx_campaign.gd') -WorkingDirectory $checkout -NoNewWindow -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
$proc.Refresh()
$wmi=Get-CimInstance Win32_Process -Filter "ProcessId = $($proc.Id)"
$start=[ordered]@{attempt_id='CX_GEOMETRY_FINAL03';started_utc=[DateTime]::UtcNow.ToString('o');launcher_pid=$launcherPid;godot_pid=$proc.Id;godot_parent_pid=$wmi.ParentProcessId;command_line=$wmi.CommandLine;executable_path=$wmi.ExecutablePath;source_sha=$env:R12C_SOURCE_SHA;parent_sha=$env:R12C_PARENT_SHA;tree_sha=$env:R12C_TREE_SHA}
[IO.File]::WriteAllText((Join-Path $run 'process-start.json'),($start|ConvertTo-Json -Depth 4),[Text.Encoding]::UTF8)
Write-Host "R12CX_PROCESS_STARTED pid=$($proc.Id) parent=$($wmi.ParentProcessId)"
$samplePath=Join-Path $run 'resource_samples.jsonl'
while(-not $proc.HasExited){
 $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 $free=[int64]$memory.CommitLimit-[int64]$memory.CommittedBytes
 $current=Get-CimInstance Win32_Process -Filter "ProcessId = $($proc.Id)"
 $sample=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');elapsed_ms=$sw.ElapsedMilliseconds;free_commit_bytes=$free;free_commit_gib=[math]::Round($free/1GB,3);commit_limit_bytes=[int64]$memory.CommitLimit;committed_bytes=[int64]$memory.CommittedBytes;godot_pid=$proc.Id;godot_working_set_bytes=if($null -ne $current){[int64]$current.WorkingSetSize}else{$null};warning=($free -le 3GB);hard_abort=($free -le 2GB)}
 [IO.File]::AppendAllText($samplePath,(($sample|ConvertTo-Json -Compress)+[Environment]::NewLine),[Text.Encoding]::UTF8)
 if($free -le 2GB){Write-Host "R12CX_HARD_ABORT_THRESHOLD pid=$($proc.Id)"}
 Start-Sleep -Milliseconds 400
 $proc.Refresh()
}
$proc.WaitForExit()
$sw.Stop()
$end=[ordered]@{attempt_id='CX_GEOMETRY_FINAL03';completed_utc=[DateTime]::UtcNow.ToString('o');launcher_pid=$launcherPid;godot_pid=$proc.Id;exit_code=$proc.ExitCode;duration_ms=$sw.ElapsedMilliseconds;stdout_sha256=(Get-FileHash $stdout -Algorithm SHA256).Hash.ToLower();stderr_sha256=(Get-FileHash $stderr -Algorithm SHA256).Hash.ToLower();resource_sample_count=if(Test-Path $samplePath){@(Get-Content $samplePath).Count}else{0}}
[IO.File]::WriteAllText((Join-Path $run 'process-complete.json'),($end|ConvertTo-Json -Depth 4),[Text.Encoding]::UTF8)
Write-Host "R12CX_PROCESS_COMPLETE pid=$($proc.Id) exit=$($proc.ExitCode) duration_ms=$($sw.ElapsedMilliseconds)"
exit $proc.ExitCode