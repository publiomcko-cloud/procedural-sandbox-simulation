[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Worktree,
  [Parameter(Mandatory)][string]$EvidenceRoot,
  [Parameter(Mandatory)][string]$GodotExe,
  [Parameter(Mandatory)][string]$SourceSha,
  [Parameter(Mandatory)][string]$CampaignSha256,
  [Parameter(Mandatory)][string]$RealizerSha256,
  [Parameter(Mandatory)][string]$Stage0Path,
  [Parameter(Mandatory)][string]$ResidualPath,
  [Parameter(Mandatory)][string]$ResidualSha256,
  [Parameter(Mandatory)][string]$C6CampaignSha256,
  [Parameter(Mandatory)][string]$C6RealizerSha256
)
$ErrorActionPreference = 'Stop'
function Write-NewText([string]$Path, [string]$Text) {
  $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Text)
  $stream = [IO.FileStream]::new($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::WriteThrough)
  try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
}
function Invoke-Gate([string]$Name, [string[]]$Argv, [hashtable]$Environment = @{}) {
  $profileRoot = Join-Path $EvidenceRoot 'godot-user-profile'
  $appData = Join-Path $profileRoot 'roaming'
  $localAppData = Join-Path $profileRoot 'local'
  $tempData = Join-Path $profileRoot 'temp'
  foreach($directory in @($appData,$localAppData,$tempData)) { New-Item -ItemType Directory -Force -Path $directory | Out-Null }
  $psi = [Diagnostics.ProcessStartInfo]::new()
  $psi.FileName = $GodotExe
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.WorkingDirectory = $Worktree
  $psi.EnvironmentVariables['APPDATA'] = $appData
  $psi.EnvironmentVariables['LOCALAPPDATA'] = $localAppData
  $psi.EnvironmentVariables['TEMP'] = $tempData
  $psi.EnvironmentVariables['TMP'] = $tempData
  foreach($key in $Environment.Keys) { $psi.EnvironmentVariables[$key] = [string]$Environment[$key] }
  foreach($argument in $Argv) { $psi.ArgumentList.Add([string]$argument) }
  $process = [Diagnostics.Process]::new()
  $process.StartInfo = $psi
  $start = [DateTime]::UtcNow
  if(-not $process.Start()) { throw "Could not start gate $Name." }
  $pidValue = $process.Id
  $stdoutTask = $process.StandardOutput.ReadToEndAsync()
  $stderrTask = $process.StandardError.ReadToEndAsync()
  if(-not $process.WaitForExit(300000)) {
    try { $process.Kill($true); $process.WaitForExit() } catch {}
    $status = [ordered]@{name=$Name;status='TIMEOUT_TERMINATED';exit_code='UNKNOWN_NOT_CAPTURED';pid=$pidValue;started_utc=$start.ToString('o');duration_ms=[int]([DateTime]::UtcNow-$start).TotalMilliseconds;argv=$Argv}
    Write-NewText (Join-Path $EvidenceRoot "$Name.result.json") (ConvertTo-Json $status -Depth 8)
    throw "Gate $Name timed out; stopped sequence."
  }
  $stdout = $stdoutTask.GetAwaiter().GetResult()
  $stderr = $stderrTask.GetAwaiter().GetResult()
  $exitCode = $process.ExitCode
  Write-NewText (Join-Path $EvidenceRoot "$Name.stdout.log") $stdout
  Write-NewText (Join-Path $EvidenceRoot "$Name.stderr.log") $stderr
  $status = [ordered]@{name=$Name;status=$(if($exitCode -eq 0){'PASS'}else{'FAIL'});exit_code=$exitCode;pid=$pidValue;started_utc=$start.ToString('o');completed_utc=[DateTime]::UtcNow.ToString('o');duration_ms=[int]([DateTime]::UtcNow-$start).TotalMilliseconds;argv=$Argv;stdout_sha256=(Get-FileHash -LiteralPath (Join-Path $EvidenceRoot "$Name.stdout.log") -Algorithm SHA256).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath (Join-Path $EvidenceRoot "$Name.stderr.log") -Algorithm SHA256).Hash.ToLowerInvariant()}
  Write-NewText (Join-Path $EvidenceRoot "$Name.result.json") (ConvertTo-Json $status -Depth 8)
  Write-Output (ConvertTo-Json $status -Compress -Depth 8)
  if($exitCode -ne 0) { throw "Gate $Name returned exit code $exitCode; stopping." }
}
$game = Join-Path $Worktree 'game'
Invoke-Gate 'editor-import' @('--headless','--path',$game,'--editor','--import')
Invoke-Gate 'realizer-check-only' @('--headless','--path',$game,'--check-only','--script','res://tests/prototypes/p3_1_r12_cxr_field_support_realizer.gd')
Invoke-Gate 'contract-suite' @('--headless','--path',$game,'--script','res://tests/prototypes/p3_1_r12_cxr_contract_tests.gd')
$envMap = @{
  R12CXR_MODE='check-only'
  R12CXR_PHASE='r3'
  R12CXR_ATTEMPT_ID='R3_PRETARGET_16C3DBE_02'
  R12CXR_SOURCE_SHA=$SourceSha
  R12CXR_ARTIFACT_DIR=$EvidenceRoot
  R12CXR_FIXTURE_PATH=$Stage0Path
  R12CXR_RESIDUAL_FIXTURE_PATH=$ResidualPath
  R12CXR_EXPECTED_CAMPAIGN_SHA256=$CampaignSha256
  R12CXR_EXPECTED_REALIZER_SHA256=$RealizerSha256
  R12CXR_EXPECTED_C6_CAMPAIGN_SHA256=$C6CampaignSha256
  R12CXR_EXPECTED_C6_REALIZER_SHA256=$C6RealizerSha256
  R12CXR_EXPECTED_RESIDUAL_FIXTURE_SHA256=$ResidualSha256
}
Invoke-Gate 'campaign-internal-check-only' @('--headless','--path',$game,'--script','res://tests/prototypes/p3_1_r12_cxr_campaign.gd') $envMap


