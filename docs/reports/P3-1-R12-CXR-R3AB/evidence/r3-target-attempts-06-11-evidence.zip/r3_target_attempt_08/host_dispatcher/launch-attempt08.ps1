$ErrorActionPreference='Stop'
$root='C:\r12cxr-r3ab-convergence-20261031\docs\reports\P3-1-R12-CXR-R3AB\evidence\r3_target_attempt_08'
$repo='C:\r12cxr-r3ab-target-2d23755'
$dispatch=Join-Path $root 'host_dispatcher\r3ab_target_dispatcher.ps1'
$pwsh=Join-Path $PSHOME 'pwsh.exe'
$ev=Join-Path $root 'engine_evidence'
$argsList=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',$dispatch,'-RunFrozenTarget','-RepoRoot',$repo,'-EvidenceRoot',$ev,'-GodotExe','C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe','-ExecutionCheckoutHead','2d23755a52f316e54e0569bf0dd421324669fd69','-SourceSha','2d23755a52f316e54e0569bf0dd421324669fd69','-ContractTestsSha256','9441e441ca9d522cba02a4d2ae1ecf36a927b2311949b369e283e734bae6ef3a','-AttemptId','R3_TARGET_20261031_08','-CampaignSha256','dc8f240262c04e4947328bea164893f4749c2cb12506c5c9b770e449487650c6','-RealizerSha256','e04f20875fbb6a73acdce2c8a883890ab8060f3da7bad9e3cea7177ba5e0dac1','-Stage0Path',(Join-Path $root 'inputs\stage0-topology.json'),'-ResidualPath',(Join-Path $root 'inputs\residual-c6.json'),'-C6CampaignSha256','9a695705c47ad6473b773bbfaeaf35d88306cee6804113a0b1a71c6faca2f348','-C6RealizerSha256','31947e1944a017442ad14cc4f098e67db800d4f5e196d07e047b93dc0fe9d2ac','-ResidualSha256','ad000594b25a82459da824b7488b2a553392a86e117eb64535b182463847ff23')
$intentPath=Join-Path $root 'host_dispatcher\child-dispatch-intent.json'
if(Test-Path $intentPath){throw 'Intent exists; refusing duplicate dispatch.'}
$intent=[ordered]@{attempt_id='R3_TARGET_20261031_08';launcher_pid=$PID;dispatcher=$dispatch;dispatcher_sha256=(Get-FileHash $dispatch -Algorithm SHA256).Hash.ToLowerInvariant();child=$pwsh;argv=$argsList;utc=[DateTime]::UtcNow.ToString('o');status='PROCESS_START_CALL_IMMINENT'}
$b=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-Json $intent -Depth 12)+[Environment]::NewLine)
$f=[IO.FileStream]::new($intentPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::WriteThrough)
try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}
$psi=[Diagnostics.ProcessStartInfo]::new()
$psi.FileName=$pwsh;$psi.WorkingDirectory=$repo;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
foreach($a in $argsList){$psi.ArgumentList.Add([string]$a)}
$p=[Diagnostics.Process]::new();$p.StartInfo=$psi
$t0=[DateTime]::UtcNow
if(-not $p.Start()){throw 'Dispatcher Process.Start returned false.'}
$pidChild=$p.Id
$o=$p.StandardOutput.ReadToEndAsync();$e=$p.StandardError.ReadToEndAsync()
if(-not $p.WaitForExit(120000)){throw 'Dispatcher wrapper timeout; preserve attempt and inspect engine evidence before any retry.'}
$stdout=$o.GetAwaiter().GetResult();$stderr=$e.GetAwaiter().GetResult()
$logOut=Join-Path $root 'host_dispatcher\child.stdout.log';$logErr=Join-Path $root 'host_dispatcher\child.stderr.log'
[IO.File]::WriteAllText($logOut,$stdout,[Text.UTF8Encoding]::new($false));[IO.File]::WriteAllText($logErr,$stderr,[Text.UTF8Encoding]::new($false))
[ordered]@{attempt_id='R3_TARGET_20261031_08';launcher_pid=$PID;dispatcher_pid=$pidChild;exit_code=$p.ExitCode;started_utc=$t0.ToString('o');completed_utc=[DateTime]::UtcNow.ToString('o');stdout_sha256=(Get-FileHash $logOut -Algorithm SHA256).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash $logErr -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json -Compress|Write-Output
exit $p.ExitCode
